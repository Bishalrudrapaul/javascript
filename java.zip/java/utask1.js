

let x;
console.log(typeof x); 


