let x;
console.log(typeof x); 
x=null;
console.log(typeof x); 